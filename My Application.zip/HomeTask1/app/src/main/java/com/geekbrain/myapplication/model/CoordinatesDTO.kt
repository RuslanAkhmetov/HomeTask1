package com.geekbrain.myapplication.model


import com.google.gson.annotations.SerializedName


data class CoordinatesDTO (

    @SerializedName("response" ) var response : response? = response()

)
