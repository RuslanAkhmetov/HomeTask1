package com.geekbrain.myapplication.repository

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.geekbrain.myapplication.model.*
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Collections

const val LOCATION = "location"

class WeatherRepository private constructor(_context: Context) : Repository { //context Application

    private val TAG = "WeatherRepository"

    val context = _context

    private var listWeatherSent: MutableList<Weather> = mutableListOf()
    private var listWeatherReceived:  MutableList<Weather> =Collections.synchronizedList( mutableListOf())

    private lateinit var fusedLocationClient: FusedLocationProviderClient


    override fun getWeatherFromRepository(): MutableList<Weather> = listWeatherReceived

    companion object {
        private var instance: WeatherRepository? = null
        fun initialize(context: Context) {
            if (instance == null)
                instance = WeatherRepository(context)
        }

        fun get(): WeatherRepository {
            return instance ?: throw IllegalStateException("MovieRepository must be initialized")
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override suspend fun refreshWeatherList() {
        withContext(Dispatchers.IO) {
            synchronized(listWeatherReceived) {
            try {
                //Add weather for current position
                getWeatherForCurrentPosition()

                getWeatherFromServer(getWeatherFromLocalStorageRus() + getWeatherFromLocalStorageWorld())

            } catch (e: Exception) {
                throw e
            }
        }
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun getWeatherForCurrentPosition() {

            fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            if (context.checkSelfPermission(
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && context.checkSelfPermission(
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Toast.makeText(
                    context, "Application require Location Permition",
                    Toast.LENGTH_SHORT
                ).show()
            }
            fusedLocationClient.lastLocation
                .addOnSuccessListener {
                    Log.i(TAG, "getWeatherForCurrentPosition: $it")
                    listWeatherReceived.add(
                        Weather(
                            City(
                                "CurrentPoint", true,
                                it?.longitude?.toFloat(), it?.latitude?.toFloat()
                            ), null
                        )
                    )
                    Log.i(TAG, "refreshWeatherList: ${listWeatherReceived.size}")
                }

    }


    private val coordinatesLoaderListener =
        object : CoordinatesLoader.CoordinateLoaderListener {
            @RequiresApi(Build.VERSION_CODES.N)
            override fun onLoaded(city: City) {
                WeatherLoader(onWeatherLoaderListener, city).apply {
                    loaderWeather()
                }
            }

            override fun onFailed(throwable: Throwable) {
                Log.i(TAG, "CoordinatesLoaderFailed: " + throwable.message)
                throw throwable
            }

        }

    private val onWeatherLoaderListener: WeatherLoader.WeatherLoaderListener =
        object : WeatherLoader.WeatherLoaderListener {
            override fun onLoaded(weather: Weather) {
                listWeatherReceived.add(weather)
            }

            override fun onFailed(throwable: Throwable) {
                Log.i(TAG, "weatherLoaderFailed: " + throwable.message)
                throw throwable
            }

        }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun getWeatherFromServer(listWeather: List<Weather>) {
        synchronized(listWeather) {
            Log.i(TAG, "getWeatherFromServer size of listweather: ${listWeather.size}")
            for (weatherItem in listWeather) {
                try {
                    if (weatherItem.city.lat == null || weatherItem.city.lon == null) {
                        CoordinatesLoader(coordinatesLoaderListener, weatherItem.city)
                            .also {
                                it.getCoordinates()
                            }
                    } else {
                        val loader = WeatherLoader(onWeatherLoaderListener, weatherItem.city)
                        Log.i(TAG, "getWeatherFromServer: ${weatherItem.city}")
                        loader.loaderWeather()
                    }
                } catch (e: Exception) {
                    Log.i(TAG, "getWeatherFromServerFailed: " + e.message)
                    throw e
                }
            }
            Log.i(TAG, "getWeatherFromServer: listWeatherReceived " + listWeatherReceived.size)
        }
    }

    override fun getWeatherFromLocalStorageRus(): List<Weather> = getRussianCities() + listWeatherReceived

    override fun getWeatherFromLocalStorageWorld(): List<Weather> = getWorldCities()


}