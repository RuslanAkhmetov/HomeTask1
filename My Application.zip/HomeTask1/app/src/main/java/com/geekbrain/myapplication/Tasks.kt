package com.geekbrain.myapplication

import androidx.annotation.StringRes

data class Tasks(@StringRes val task: Int, var done: Boolean)
